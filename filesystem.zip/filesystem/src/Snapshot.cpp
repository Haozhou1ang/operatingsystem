// filesystem/src/Snapshot.cpp
#include "Snapshot.h"
#include "Cache.h"
#include <cstring>
#include <ctime>
#include <algorithm>

namespace fs {

//==============================================================================
// 构造与析构
//==============================================================================

SnapshotManager::SnapshotManager(Allocator* alloc, Directory* dir, DiskImage* disk)
    : alloc_(alloc)
    , dir_(dir)
    , disk_(disk)
    , cached_disk_(nullptr)
    , use_cached_disk_(false)
    , snapshot_list_block_(INVALID_BLOCK)
    , loaded_(false)
    , dirty_(false)
    , stats_{0, 0, 0, 0}
{
}

SnapshotManager::SnapshotManager(Allocator* alloc, Directory* dir, CachedDisk* cached_disk)
    : alloc_(alloc)
    , dir_(dir)
    , disk_(cached_disk ? cached_disk->getDisk() : nullptr)
    , cached_disk_(cached_disk)
    , use_cached_disk_(cached_disk != nullptr)
    , snapshot_list_block_(INVALID_BLOCK)
    , loaded_(false)
    , dirty_(false)
    , stats_{0, 0, 0, 0}
{
}

SnapshotManager::~SnapshotManager() {
    if (loaded_ && dirty_) {
        sync();
    }
}

//==============================================================================
// 块读写内部接口
//==============================================================================

ErrorCode SnapshotManager::readBlockInternal(BlockNo block_no, void* buffer) {
    if (use_cached_disk_ && cached_disk_) {
        return cached_disk_->readBlock(block_no, buffer);
    }
    if (disk_) {
        return disk_->readBlock(block_no, buffer);
    }
    return ErrorCode::E_IO;
}

ErrorCode SnapshotManager::writeBlockInternal(BlockNo block_no, const void* buffer) {
    if (use_cached_disk_ && cached_disk_) {
        return cached_disk_->writeBlock(block_no, buffer);
    }
    if (disk_) {
        return disk_->writeBlock(block_no, buffer);
    }
    return ErrorCode::E_IO;
}

//==============================================================================
// 初始化接口
//==============================================================================

ErrorCode SnapshotManager::load() {
    std::lock_guard<std::mutex> lock(mutex_);

    if (!alloc_) {
        return ErrorCode::E_INVALID_PARAM;
    }

    const Superblock& sb = alloc_->getSuperblock();
    snapshot_list_block_ = sb.snapshot_list_block;

    if (snapshot_list_block_ == 0 || snapshot_list_block_ == INVALID_BLOCK) {
        snapshots_.clear();
        loaded_ = true;
        dirty_ = false;
        return ErrorCode::OK;
    }

    ErrorCode err = loadSnapshotList();
    if (err != ErrorCode::OK) {
        return err;
    }

    loaded_ = true;
    dirty_ = false;
    stats_.total_snapshots = static_cast<uint32_t>(snapshots_.size());

    return ErrorCode::OK;
}

ErrorCode SnapshotManager::sync() {
    std::lock_guard<std::mutex> lock(mutex_);

    if (!loaded_) {
        return ErrorCode::OK;
    }
    
    if (!dirty_ && snapshots_.empty()) {
        return ErrorCode::OK;
    }

    ErrorCode err = saveSnapshotList();
    if (err != ErrorCode::OK) {
        return err;
    }

    dirty_ = false;
    return alloc_->sync();
}

//==============================================================================
// 快照列表磁盘操作
//==============================================================================

ErrorCode SnapshotManager::loadSnapshotList() {
    if (snapshot_list_block_ == 0 || snapshot_list_block_ == INVALID_BLOCK) {
        snapshots_.clear();
        return ErrorCode::OK;
    }

    uint8_t block_data[BLOCK_SIZE];
    ErrorCode err = readBlockInternal(snapshot_list_block_, block_data);
    if (err != ErrorCode::OK) {
        return err;
    }

    uint32_t count = *reinterpret_cast<uint32_t*>(block_data);
    
    if (count > MAX_SNAPSHOTS) {
        count = MAX_SNAPSHOTS;
    }

    snapshots_.clear();
    snapshots_.reserve(count);

    SnapshotMeta* metas = reinterpret_cast<SnapshotMeta*>(block_data + 8);

    for (uint32_t i = 0; i < count; ++i) {
        if (metas[i].isValid()) {
            SnapshotInfo info;
            info.name = metas[i].getName();
            info.create_time = metas[i].create_time;
            info.root_inode = metas[i].root_inode;
            info.block_count = metas[i].block_count;
            info.valid = true;
            snapshots_.push_back(info);
        }
    }

    return ErrorCode::OK;
}

ErrorCode SnapshotManager::saveSnapshotList() {
    if (snapshots_.empty() && 
        (snapshot_list_block_ == 0 || snapshot_list_block_ == INVALID_BLOCK)) {
        return ErrorCode::OK;
    }
    
    if (snapshot_list_block_ == 0 || snapshot_list_block_ == INVALID_BLOCK) {
        ErrorCode err = allocSnapshotListBlock();
        if (err != ErrorCode::OK) {
            return err;
        }
    }

    uint8_t block_data[BLOCK_SIZE];
    std::memset(block_data, 0, BLOCK_SIZE);

    *reinterpret_cast<uint32_t*>(block_data) = static_cast<uint32_t>(snapshots_.size());

    SnapshotMeta* metas = reinterpret_cast<SnapshotMeta*>(block_data + 8);

    for (size_t i = 0; i < snapshots_.size() && i < MAX_SNAPSHOTS; ++i) {
        const SnapshotInfo& info = snapshots_[i];
        
        std::memset(&metas[i], 0, sizeof(SnapshotMeta));
        
        size_t name_len = std::min(info.name.size(), static_cast<size_t>(MAX_SNAPSHOT_NAME_LEN - 1));
        std::memcpy(metas[i].name, info.name.c_str(), name_len);
        
        metas[i].create_time = info.create_time;
        metas[i].root_inode = info.root_inode;
        metas[i].block_count = info.block_count;
        metas[i].flags = info.valid ? 0x0001 : 0x0000;
    }

    return writeBlockInternal(snapshot_list_block_, block_data);
}

ErrorCode SnapshotManager::allocSnapshotListBlock() {
    auto result = alloc_->allocBlock();
    if (!result.ok()) {
        return result.error();
    }

    snapshot_list_block_ = result.value();

    Superblock& sb = alloc_->getSuperblockMutable();
    sb.snapshot_list_block = snapshot_list_block_;

    return ErrorCode::OK;
}

int32_t SnapshotManager::findSnapshotIndex(const std::string& name) const {
    for (size_t i = 0; i < snapshots_.size(); ++i) {
        if (snapshots_[i].name == name && snapshots_[i].valid) {
            return static_cast<int32_t>(i);
        }
    }
    return -1;
}

//==============================================================================
// 快照操作接口
//==============================================================================

ErrorCode SnapshotManager::createSnapshot(const std::string& name) {
    std::lock_guard<std::mutex> lock(mutex_);

    if (!loaded_) {
        return ErrorCode::E_INVALID_PARAM;
    }

    // 验证名称
    if (name.empty() || name.size() > MAX_SNAPSHOT_NAME_LEN - 1) {
        return ErrorCode::E_NAME_TOO_LONG;
    }

    // 检查是否已存在
    if (findSnapshotIndex(name) >= 0) {
        return ErrorCode::E_SNAPSHOT_EXISTS;
    }

    // 检查数量限制
    if (snapshots_.size() >= MAX_SNAPSHOTS) {
        return ErrorCode::E_MAX_SNAPSHOTS;
    }

    // 获取当前根 inode
    const Superblock& sb = alloc_->getSuperblock();
    InodeId current_root = sb.root_inode;

    // 读取根 inode
    auto root_result = alloc_->readInode(current_root);
    if (!root_result.ok()) {
        return root_result.error();
    }

    Inode root_inode = root_result.value();
    
    // 增加数据块的引用计数
    ErrorCode err = incrementBlockRefs(root_inode);
    if (err != ErrorCode::OK) {
        return err;
    }

    // 增加 inode 的引用计数
    root_inode.ref_count++;
    alloc_->writeInode(current_root, root_inode);

    // 创建快照信息
    SnapshotInfo info;
    info.name = name;
    info.create_time = currentTime();
    info.root_inode = current_root;
    info.block_count = root_inode.block_count;
    info.valid = true;

    snapshots_.push_back(info);
    dirty_ = true;
    stats_.total_snapshots++;

    // 更新 superblock 中的快照计数
    Superblock& sb_mut = alloc_->getSuperblockMutable();
    sb_mut.snapshot_count = static_cast<uint32_t>(snapshots_.size());

    // 保存快照列表
    err = saveSnapshotList();
    if (err != ErrorCode::OK) {
        return err;
    }

    // 同步到磁盘
    err = alloc_->sync();
    if (err != ErrorCode::OK) {
        return err;
    }

    dirty_ = false;
    return ErrorCode::OK;
}

ErrorCode SnapshotManager::restoreSnapshot(const std::string& name) {
    std::lock_guard<std::mutex> lock(mutex_);

    if (!loaded_) {
        return ErrorCode::E_INVALID_PARAM;
    }

    int32_t idx = findSnapshotIndex(name);
    if (idx < 0) {
        return ErrorCode::E_SNAPSHOT_NOT_FOUND;
    }

    const SnapshotInfo& snapshot = snapshots_[idx];

    // 读取快照的根 inode
    auto snapshot_root_result = alloc_->readInode(snapshot.root_inode);
    if (!snapshot_root_result.ok()) {
        return snapshot_root_result.error();
    }

    // 将快照的根 inode 内容复制到 ROOT_INODE
    Inode restored = snapshot_root_result.value();
    restored.ref_count = 1;
    
    ErrorCode err = alloc_->writeInode(ROOT_INODE, restored);
    if (err != ErrorCode::OK) {
        return err;
    }

    // 刷新缓存
    if (use_cached_disk_ && cached_disk_) {
        cached_disk_->clearCache();
    }

    return alloc_->sync();
}

ErrorCode SnapshotManager::deleteSnapshot(const std::string& name) {
    std::lock_guard<std::mutex> lock(mutex_);

    if (!loaded_) {
        return ErrorCode::E_INVALID_PARAM;
    }

    int32_t idx = findSnapshotIndex(name);
    if (idx < 0) {
        return ErrorCode::E_SNAPSHOT_NOT_FOUND;
    }

    const SnapshotInfo& snapshot = snapshots_[idx];

    // 读取快照根 inode
    auto root_result = alloc_->readInode(snapshot.root_inode);
    if (root_result.ok()) {
        Inode root = root_result.value();
        
        // 减少引用计数
        if (root.ref_count > 1) {
            root.ref_count--;
            alloc_->writeInode(snapshot.root_inode, root);
            decrementBlockRefs(root);
        }
    }

    // 从列表中移除
    snapshots_.erase(snapshots_.begin() + idx);
    dirty_ = true;
    stats_.total_snapshots = static_cast<uint32_t>(snapshots_.size());

    // 更新 superblock
    Superblock& sb = alloc_->getSuperblockMutable();
    sb.snapshot_count = static_cast<uint32_t>(snapshots_.size());

    return saveSnapshotList();
}

std::vector<SnapshotInfo> SnapshotManager::listSnapshots() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return snapshots_;
}

Result<SnapshotInfo> SnapshotManager::getSnapshot(const std::string& name) const {
    std::lock_guard<std::mutex> lock(mutex_);

    int32_t idx = findSnapshotIndex(name);
    if (idx < 0) {
        return Result<SnapshotInfo>::failure(ErrorCode::E_SNAPSHOT_NOT_FOUND);
    }

    return Result<SnapshotInfo>::success(snapshots_[idx]);
}

bool SnapshotManager::snapshotExists(const std::string& name) const {
    std::lock_guard<std::mutex> lock(mutex_);
    return findSnapshotIndex(name) >= 0;
}

uint32_t SnapshotManager::getSnapshotCount() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return static_cast<uint32_t>(snapshots_.size());
}

//==============================================================================
// COW (Copy-on-Write) 接口
//==============================================================================

bool SnapshotManager::needsCOW(BlockNo block_no) const {
    if (snapshots_.empty()) {
        return false;
    }
    uint32_t ref_count = alloc_->getBlockRef(block_no);
    return ref_count > 1;
}

Result<BlockNo> SnapshotManager::performCOW(BlockNo block_no) {
    std::lock_guard<std::mutex> lock(mutex_);

    if (!needsCOW(block_no)) {
        return Result<BlockNo>::success(block_no);
    }

    // 分配新块
    auto alloc_result = alloc_->allocBlock();
    if (!alloc_result.ok()) {
        return alloc_result;
    }

    BlockNo new_block = alloc_result.value();

    // 复制数据
    uint8_t buffer[BLOCK_SIZE];
    ErrorCode err = readBlockInternal(block_no, buffer);
    if (err != ErrorCode::OK) {
        alloc_->freeBlock(new_block);
        return Result<BlockNo>::failure(err);
    }

    err = writeBlockInternal(new_block, buffer);
    if (err != ErrorCode::OK) {
        alloc_->freeBlock(new_block);
        return Result<BlockNo>::failure(err);
    }

    // 减少原块引用计数
    alloc_->decBlockRef(block_no);
    stats_.cow_operations++;

    return Result<BlockNo>::success(new_block);
}

ErrorCode SnapshotManager::cowWriteBlock(BlockNo block_no, const void* data, 
                                          BlockNo& new_block_no) {
    std::lock_guard<std::mutex> lock(mutex_);

    if (needsCOW(block_no)) {
        auto alloc_result = alloc_->allocBlock();
        if (!alloc_result.ok()) {
            return alloc_result.error();
        }

        new_block_no = alloc_result.value();

        ErrorCode err = writeBlockInternal(new_block_no, data);
        if (err != ErrorCode::OK) {
            alloc_->freeBlock(new_block_no);
            return err;
        }

        alloc_->decBlockRef(block_no);
        stats_.cow_operations++;
    } else {
        new_block_no = block_no;
        ErrorCode err = writeBlockInternal(block_no, data);
        if (err != ErrorCode::OK) {
            return err;
        }
    }

    return ErrorCode::OK;
}

//==============================================================================
// 引用计数操作
//==============================================================================

ErrorCode SnapshotManager::incrementBlockRefs(const Inode& inode) {
    // 直接块
    for (uint32_t i = 0; i < NUM_DIRECT_BLOCKS; ++i) {
        if (inode.direct_blocks[i] != INVALID_BLOCK) {
            alloc_->incBlockRef(inode.direct_blocks[i]);
            stats_.shared_blocks++;
        }
    }

    // 一级间接块
    if (inode.single_indirect != INVALID_BLOCK) {
        alloc_->incBlockRef(inode.single_indirect);
        
        uint8_t block_data[BLOCK_SIZE];
        if (readBlockInternal(inode.single_indirect, block_data) == ErrorCode::OK) {
            BlockNo* ptrs = reinterpret_cast<BlockNo*>(block_data);
            for (uint32_t i = 0; i < PTRS_PER_BLOCK; ++i) {
                if (ptrs[i] != INVALID_BLOCK) {
                    alloc_->incBlockRef(ptrs[i]);
                    stats_.shared_blocks++;
                }
            }
        }
    }

    // 二级间接块
    if (inode.double_indirect != INVALID_BLOCK) {
        alloc_->incBlockRef(inode.double_indirect);
        
        uint8_t l1_data[BLOCK_SIZE];
        if (readBlockInternal(inode.double_indirect, l1_data) == ErrorCode::OK) {
            BlockNo* l1_ptrs = reinterpret_cast<BlockNo*>(l1_data);
            
            for (uint32_t i = 0; i < PTRS_PER_BLOCK; ++i) {
                if (l1_ptrs[i] != INVALID_BLOCK) {
                    alloc_->incBlockRef(l1_ptrs[i]);
                    
                    uint8_t l2_data[BLOCK_SIZE];
                    if (readBlockInternal(l1_ptrs[i], l2_data) == ErrorCode::OK) {
                        BlockNo* l2_ptrs = reinterpret_cast<BlockNo*>(l2_data);
                        for (uint32_t j = 0; j < PTRS_PER_BLOCK; ++j) {
                            if (l2_ptrs[j] != INVALID_BLOCK) {
                                alloc_->incBlockRef(l2_ptrs[j]);
                                stats_.shared_blocks++;
                            }
                        }
                    }
                }
            }
        }
    }

    return ErrorCode::OK;
}

ErrorCode SnapshotManager::decrementBlockRefs(const Inode& inode) {
    // 直接块
    for (uint32_t i = 0; i < NUM_DIRECT_BLOCKS; ++i) {
        if (inode.direct_blocks[i] != INVALID_BLOCK) {
            alloc_->decBlockRef(inode.direct_blocks[i]);
        }
    }

    // 一级间接块
    if (inode.single_indirect != INVALID_BLOCK) {
        uint8_t block_data[BLOCK_SIZE];
        if (readBlockInternal(inode.single_indirect, block_data) == ErrorCode::OK) {
            BlockNo* ptrs = reinterpret_cast<BlockNo*>(block_data);
            for (uint32_t i = 0; i < PTRS_PER_BLOCK; ++i) {
                if (ptrs[i] != INVALID_BLOCK) {
                    alloc_->decBlockRef(ptrs[i]);
                }
            }
        }
        alloc_->decBlockRef(inode.single_indirect);
    }

    // 二级间接块
    if (inode.double_indirect != INVALID_BLOCK) {
        uint8_t l1_data[BLOCK_SIZE];
        if (readBlockInternal(inode.double_indirect, l1_data) == ErrorCode::OK) {
            BlockNo* l1_ptrs = reinterpret_cast<BlockNo*>(l1_data);
            
            for (uint32_t i = 0; i < PTRS_PER_BLOCK; ++i) {
                if (l1_ptrs[i] != INVALID_BLOCK) {
                    uint8_t l2_data[BLOCK_SIZE];
                    if (readBlockInternal(l1_ptrs[i], l2_data) == ErrorCode::OK) {
                        BlockNo* l2_ptrs = reinterpret_cast<BlockNo*>(l2_data);
                        for (uint32_t j = 0; j < PTRS_PER_BLOCK; ++j) {
                            if (l2_ptrs[j] != INVALID_BLOCK) {
                                alloc_->decBlockRef(l2_ptrs[j]);
                            }
                        }
                    }
                    alloc_->decBlockRef(l1_ptrs[i]);
                }
            }
        }
        alloc_->decBlockRef(inode.double_indirect);
    }

    return ErrorCode::OK;
}

//==============================================================================
// 统计接口
//==============================================================================

SnapshotManager::SnapshotStats SnapshotManager::getStats() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return stats_;
}

void SnapshotManager::resetStats() {
    std::lock_guard<std::mutex> lock(mutex_);
    stats_.cow_operations = 0;
    stats_.shared_blocks = 0;
}

//==============================================================================
// 辅助方法
//==============================================================================

int64_t SnapshotManager::currentTime() {
    return static_cast<int64_t>(std::time(nullptr));
}

Result<InodeId> SnapshotManager::cloneInodeTree(InodeId src_inode) {
    auto src_result = alloc_->readInode(src_inode);
    if (!src_result.ok()) {
        return Result<InodeId>::failure(src_result.error());
    }

    Inode src = src_result.value();
    src.ref_count++;
    alloc_->writeInode(src_inode, src);

    incrementBlockRefs(src);

    return Result<InodeId>::success(src_inode);
}

ErrorCode SnapshotManager::cloneDirectoryContents(const Inode& dir_inode, InodeId new_dir_id) {
    (void)dir_inode;
    (void)new_dir_id;
    return ErrorCode::OK;
}

} // namespace fs