// server/src/services/paper.cpp
#include "services/paper.h"
#include "auth/auth.h"

#include <filesystem>
#include <fstream>
#include <sstream>
#include <algorithm>

using namespace std;
static bool IsValidSimpleName(const std::string& s) {
  if (s.empty()) return false;
  for (unsigned char c : s) {
    if ((c >= 'a' && c <= 'z') ||
        (c >= 'A' && c <= 'Z') ||
        (c >= '0' && c <= '9') ||
        c == '_' || c == '-') {
      continue;
    }
    return false;
  }
  return true;
}

std::mutex g_fs_mu;

static string Trim(string s) {
  while (!s.empty() && (s.back()=='\r' || s.back()=='\n' || s.back()==' ' || s.back()=='\t')) s.pop_back();
  size_t i=0;
  while (i<s.size() && (s[i]==' '||s[i]=='\t')) i++;
  return s.substr(i);
}

static vector<string> SplitCSVLine(const string& line) {
  vector<string> out;
  string cur;
  bool inq = false;
  for (char c : line) {
    if (c == '"') { inq = !inq; continue; }
    if (!inq && c == ',') { out.push_back(cur); cur.clear(); }
    else cur.push_back(c);
  }
  out.push_back(cur);
  return out;
}

static bool WriteTextFileLocked(const string& path, const string& content) {
  ofstream fout(path, ios::trunc);
  if (!fout.is_open()) return false;
  fout << content;
  return true;
}

static bool ReadTextFileLocked(const string& path, string& out) {
  ifstream fin(path);
  if (!fin.is_open()) return false;
  ostringstream oss;
  oss << fin.rdbuf();
  out = oss.str();
  return true;
}

PaperService::PaperService(std::string root_dir, AuthManager* auth)
  : root_(std::move(root_dir)), auth_(auth) {
  meta_path_ = root_ + "/meta.csv";
  papers_dir_ = root_ + "/papers";
}

bool PaperService::Init() {
  // strict: all resources locked
  lock_guard<mutex> fs(g_fs_mu);

  std::filesystem::create_directories(papers_dir_);
  (void)LoadMeta();   // meta.csv may not exist
  (void)SaveMeta();   // ensure file exists
  return true;
}

string PaperService::StatusToString(PaperStatus s) {
  switch (s) {
    case PaperStatus::SUBMITTED:     return "SUBMITTED";
    case PaperStatus::UNDER_REVIEW:  return "UNDER_REVIEW";
    case PaperStatus::FINISH_REVIEW: return "FINISH_REVIEW";
    case PaperStatus::ACCEPTED:      return "ACCEPTED";
    case PaperStatus::REJECTED:      return "REJECTED";
  }
  return "SUBMITTED";
}

bool PaperService::StringToStatus(const string& s, PaperStatus& out) {
  if (s=="SUBMITTED")     { out=PaperStatus::SUBMITTED; return true; }
  if (s=="UNDER_REVIEW")  { out=PaperStatus::UNDER_REVIEW; return true; }
  if (s=="FINISH_REVIEW") { out=PaperStatus::FINISH_REVIEW; return true; }
  if (s=="ACCEPTED")      { out=PaperStatus::ACCEPTED; return true; }
  if (s=="REJECTED")      { out=PaperStatus::REJECTED; return true; }
  return false;
}

// NOTE: callers should hold g_fs_mu if you want “all resources locked” strictly.
// We still lock mu_ to protect in-memory meta_.
bool PaperService::LoadMeta() {
  lock_guard<mutex> lk(mu_);
  meta_.clear();

  ifstream fin(meta_path_);
  if (!fin.is_open()) return false;

  string line;
  while (getline(fin, line)) {
    line = Trim(line);
    if (line.empty()) continue;

    auto cols = SplitCSVLine(line);
    if (cols.size() < 5) continue;

    PaperMeta m;
    m.paper_id = Trim(cols[0]);
    m.author   = Trim(cols[1]);
    PaperStatus st;
    if (!StringToStatus(Trim(cols[2]), st)) continue;
    m.status = st;
    m.reviewers = SplitSemi(Trim(cols[3]));
    m.current_version = Trim(cols[4]);

    if (m.paper_id.empty() || m.author.empty() || m.current_version.empty()) continue;
    meta_[m.paper_id] = m;
  }
  return true;
}

bool PaperService::SaveMeta() {
  lock_guard<mutex> lk(mu_);

  ofstream fout(meta_path_, ios::trunc);
  if (!fout.is_open()) return false;

  for (auto& kv : meta_) {
    auto& m = kv.second;
    fout << m.paper_id << ","
         << m.author << ","
         << StatusToString(m.status) << ","
         << JoinSemi(m.reviewers) << ","
         << m.current_version << "\n";
  }
  return true;
}

vector<string> PaperService::SplitSemi(const string& s) {
  vector<string> out;
  string cur;
  for (char c : s) {
    if (c == ';') { if (!cur.empty()) out.push_back(cur); cur.clear(); }
    else cur.push_back(c);
  }
  if (!cur.empty()) out.push_back(cur);

  for (auto& x : out) x = Trim(x);
  out.erase(remove_if(out.begin(), out.end(),
                      [](const string& x){ return x.empty(); }),
            out.end());
  return out;
}

string PaperService::JoinSemi(const vector<string>& v) {
  string out;
  for (size_t i=0;i<v.size();++i) {
    if (i) out.push_back(';');
    out += v[i];
  }
  return out;
}

bool PaperService::Has(const vector<string>& v, const string& x) {
  return find(v.begin(), v.end(), x) != v.end();
}

void PaperService::AddUnique(vector<string>& v, const string& x) {
  if (!Has(v, x)) v.push_back(x);
}

int PaperService::ParseVersionNum(const string& v) {
  if (v.size() < 2 || v[0] != 'v') return 0;
  try { return stoi(v.substr(1)); } catch (...) { return 0; }
}

string PaperService::MakeVersion(int n) {
  return "v" + to_string(n);
}

string PaperService::PaperRoot(const string& paper_id) const {
  return papers_dir_ + "/" + paper_id;
}
string PaperService::VersionsRoot(const string& paper_id) const {
  return PaperRoot(paper_id) + "/versions";
}
string PaperService::VersionDir(const string& paper_id, const string& v) const {
  return VersionsRoot(paper_id) + "/" + v;
}
string PaperService::PaperFile(const string& paper_id, const string& v) const {
  return VersionDir(paper_id, v) + "/" + v + ".txt";
}
string PaperService::ReviewsDir(const string& paper_id, const string& v) const {
  return VersionDir(paper_id, v) + "/reviews";
}

bool PaperService::PaperExistsLocked(const string& paper_id) {
  lock_guard<mutex> lk(mu_);
  return meta_.find(paper_id) != meta_.end();
}

bool PaperService::EnsurePaperDirsLocked(const string& paper_id) {
  std::filesystem::create_directories(VersionsRoot(paper_id));
  return true;
}

bool PaperService::AllReviewsDoneLocked(const PaperMeta& m) {
  // caller should hold g_fs_mu
  if (m.reviewers.empty()) return false;
  const string& v = m.current_version;
  string rdir = ReviewsDir(m.paper_id, v);

  for (const auto& rv : m.reviewers) {
    string f = rdir + "/" + rv + ".txt";
    if (!std::filesystem::exists(f)) return false;
  }
  return true;
}

bool PaperService::Upload(const string& token, const string& paper_id, const string& content,
                          int& err_code, string& err_msg) {
  err_code=0; err_msg.clear();
  if (token.empty() || paper_id.empty() || content.empty()) {
    err_code=400; err_msg="empty_fields";
    return false;
  }

  // NEW: paper_id allow [A-Za-z0-9_-]
  if (!IsValidSimpleName(paper_id)) {
    err_code = 400;
    err_msg = "invalid_paper_id";
    return false;
  }

  SessionInfo s;
  auto st = auth_->CheckToken(token, &s);
  if (st != TokenState::OK) {
    err_code = (st==TokenState::EXPIRED?403:(st==TokenState::NOT_FOUND?404:400));
    err_msg  = (st==TokenState::EXPIRED?"token_expired":(st==TokenState::NOT_FOUND?"token_not_found":"empty_token"));
    return false;
  }
  if (s.role != "AUTHOR") {
    err_code=403; err_msg="permission_denied";
    return false;
  }

  scoped_lock lk(g_fs_mu, mu_);

  if (meta_.find(paper_id) != meta_.end()) {
    err_code=409; err_msg="paper_exists";
    return false;
  }

  EnsurePaperDirsLocked(paper_id);
  std::filesystem::create_directories(VersionDir(paper_id, "v1"));
  std::filesystem::create_directories(ReviewsDir(paper_id, "v1"));
  if (!WriteTextFileLocked(PaperFile(paper_id, "v1"), content)) {
    err_code=500; err_msg="write_failed";
    return false;
  }

  PaperMeta m;
  m.paper_id = paper_id;
  m.author = s.username;
  m.status = PaperStatus::SUBMITTED;
  m.reviewers.clear();
  m.current_version = "v1";
  meta_[paper_id] = m;

  ofstream fout(meta_path_, ios::trunc);
  if (!fout.is_open()) { err_code=500; err_msg="meta_write_failed"; return false; }
  for (auto& kv : meta_) {
    auto& mm = kv.second;
    fout << mm.paper_id << ","
         << mm.author << ","
         << StatusToString(mm.status) << ","
         << JoinSemi(mm.reviewers) << ","
         << mm.current_version << "\n";
  }
  return true;
}


bool PaperService::Revise(const string& token, const string& paper_id, const string& content,
                          int& err_code, string& err_msg) {
  err_code=0; err_msg.clear();
  if (token.empty() || paper_id.empty() || content.empty()) {
    err_code=400; err_msg="empty_fields";
    return false;
  }

  SessionInfo s;
  auto st = auth_->CheckToken(token, &s);
  if (st != TokenState::OK) {
    err_code = (st==TokenState::EXPIRED?403:(st==TokenState::NOT_FOUND?404:400));
    err_msg  = (st==TokenState::EXPIRED?"token_expired":(st==TokenState::NOT_FOUND?"token_not_found":"empty_token"));
    return false;
  }
  if (s.role != "AUTHOR") {
    err_code=403; err_msg="permission_denied";
    return false;
  }

  scoped_lock lk(g_fs_mu, mu_);

  auto it = meta_.find(paper_id);
  if (it == meta_.end()) { err_code=404; err_msg="paper_not_found"; return false; }
  if (it->second.author != s.username) { err_code=403; err_msg="not_your_paper"; return false; }

  // Spec: ACCEPTED forbids REVISE
  if (it->second.status == PaperStatus::ACCEPTED) {
    err_code=400; err_msg="paper_accepted_no_revise"; return false;
  }
  // Spec: UNDER_REVIEW or FINISH_REVIEW forbids REVISE
  if (it->second.status == PaperStatus::UNDER_REVIEW || it->second.status == PaperStatus::FINISH_REVIEW) {
    err_code=400; err_msg="paper_in_review_no_revise"; return false;
  }

  if (it->second.status == PaperStatus::SUBMITTED) {
    // overwrite current version
    const string v = it->second.current_version;
    std::filesystem::create_directories(VersionDir(paper_id, v));
    std::filesystem::create_directories(ReviewsDir(paper_id, v));
    if (!WriteTextFileLocked(PaperFile(paper_id, v), content)) {
      err_code=500; err_msg="write_failed"; return false;
    }
    return true;
  }

  // REJECTED => new version vn+1, clear reviewers, status=SUBMITTED
  if (it->second.status != PaperStatus::REJECTED) {
    // defensive (should not happen)
    err_code=400; err_msg="invalid_state_for_revise";
    return false;
  }

  int cur = ParseVersionNum(it->second.current_version);
  string nv = MakeVersion(cur + 1);

  it->second.current_version = nv;
  it->second.reviewers.clear();
  it->second.status = PaperStatus::SUBMITTED;

  std::filesystem::create_directories(VersionDir(paper_id, nv));
  std::filesystem::create_directories(ReviewsDir(paper_id, nv));
  if (!WriteTextFileLocked(PaperFile(paper_id, nv), content)) {
    err_code=500; err_msg="write_failed"; return false;
  }

  // persist meta
  ofstream fout(meta_path_, ios::trunc);
  if (!fout.is_open()) { err_code=500; err_msg="meta_write_failed"; return false; }
  for (auto& kv : meta_) {
    auto& mm = kv.second;
    fout << mm.paper_id << ","
         << mm.author << ","
         << StatusToString(mm.status) << ","
         << JoinSemi(mm.reviewers) << ","
         << mm.current_version << "\n";
  }
  return true;
}

bool PaperService::Status(const string& token, const string& paper_id,
                          string& out_body, int& err_code, string& err_msg) {
  err_code=0; err_msg.clear(); out_body.clear();
  if (token.empty() || paper_id.empty()) { err_code=400; err_msg="empty_fields"; return false; }

  SessionInfo s;
  auto st = auth_->CheckToken(token, &s);
  if (st != TokenState::OK) {
    err_code = (st==TokenState::EXPIRED?403:(st==TokenState::NOT_FOUND?404:400));
    err_msg  = (st==TokenState::EXPIRED?"token_expired":(st==TokenState::NOT_FOUND?"token_not_found":"empty_token"));
    return false;
  }

  lock_guard<mutex> fs(g_fs_mu);
  PaperMeta m;
  {
    lock_guard<mutex> lk(mu_);
    auto it = meta_.find(paper_id);
    if (it == meta_.end()) { err_code=404; err_msg="paper_not_found"; return false; }
    m = it->second;
  }

  ostringstream oss;
  oss << "paper_id=" << m.paper_id << "\n";
  oss << "author=" << m.author << "\n";
  oss << "status=" << StatusToString(m.status) << "\n";
  oss << "reviewers=" << JoinSemi(m.reviewers) << "\n";
  oss << "current_version=" << m.current_version << "\n";
  out_body = oss.str();
  return true;
}

bool PaperService::ReviewsGet(const string& token, const string& paper_id,
                             string& out_body, int& err_code, string& err_msg) {
  err_code=0; err_msg.clear(); out_body.clear();
  if (token.empty() || paper_id.empty()) { err_code=400; err_msg="empty_fields"; return false; }

  SessionInfo s;
  auto st = auth_->CheckToken(token, &s);
  if (st != TokenState::OK) {
    err_code = (st==TokenState::EXPIRED?403:(st==TokenState::NOT_FOUND?404:400));
    err_msg  = (st==TokenState::EXPIRED?"token_expired":(st==TokenState::NOT_FOUND?"token_not_found":"empty_token"));
    return false;
  }
  if (s.role != "AUTHOR") { err_code=403; err_msg="permission_denied"; return false; }

  lock_guard<mutex> fs(g_fs_mu);
  PaperMeta m;
  {
    lock_guard<mutex> lk(mu_);
    auto it = meta_.find(paper_id);
    if (it == meta_.end()) { err_code=404; err_msg="paper_not_found"; return false; }
    m = it->second;
  }
  if (m.author != s.username) { err_code=403; err_msg="not_your_paper"; return false; }

  string rdir = ReviewsDir(paper_id, m.current_version);
  if (!std::filesystem::exists(rdir)) { out_body=""; return true; }

  // NEW: stable order by filename
  std::vector<std::filesystem::path> files;
  for (auto& ent : std::filesystem::directory_iterator(rdir)) {
    if (!ent.is_regular_file()) continue;
    files.push_back(ent.path());
  }
  std::sort(files.begin(), files.end(),
            [](const auto& a, const auto& b) {
              return a.filename().string() < b.filename().string();
            });

  ostringstream oss;
  for (const auto& p : files) {
    string path = p.string();
    string name = p.filename().string();
    string content;
    if (ReadTextFileLocked(path, content)) {
      oss << "----- " << name << " -----\n";
      oss << content;
      if (!content.empty() && content.back()!='\n') oss << "\n";
    }
  }
  out_body = oss.str();
  return true;
}


bool PaperService::Papers(const string& token,
                          string& out_body, int& err_code, string& err_msg) {
  err_code = 0;
  err_msg.clear();
  out_body.clear();

  if (token.empty()) {
    err_code = 400;
    err_msg = "empty_token";
    return false;
  }

  SessionInfo s;
  auto st = auth_->CheckToken(token, &s);
  if (st != TokenState::OK) {
    err_code = (st == TokenState::EXPIRED ? 403 :
               (st == TokenState::NOT_FOUND ? 404 : 400));
    err_msg  = (st == TokenState::EXPIRED ? "token_expired" :
               (st == TokenState::NOT_FOUND ? "token_not_found" : "empty_token"));
    return false;
  }

  if (s.role != "AUTHOR") {
    err_code = 403;
    err_msg = "permission_denied";
    return false;
  }

  std::scoped_lock lk(g_fs_mu, mu_);

  std::ostringstream oss;
  for (const auto& kv : meta_) {
    const auto& m = kv.second;
    if (m.author != s.username) continue;

    oss << m.paper_id << " " << StatusToString(m.status) << "\n";
  }

  out_body = oss.str();
  return true;
}


bool PaperService::Download(const string& token, const string& paper_id,
                            string& out_body, int& err_code, string& err_msg) {
  err_code=0; err_msg.clear(); out_body.clear();
  if (token.empty() || paper_id.empty()) { err_code=400; err_msg="empty_fields"; return false; }

  SessionInfo s;
  auto st = auth_->CheckToken(token, &s);
  if (st != TokenState::OK) {
    err_code = (st==TokenState::EXPIRED?403:(st==TokenState::NOT_FOUND?404:400));
    err_msg  = (st==TokenState::EXPIRED?"token_expired":(st==TokenState::NOT_FOUND?"token_not_found":"empty_token"));
    return false;
  }
  if (s.role != "REVIEWER") { err_code=403; err_msg="permission_denied"; return false; }

  lock_guard<mutex> fs(g_fs_mu);
  PaperMeta m;
  {
    lock_guard<mutex> lk(mu_);
    auto it = meta_.find(paper_id);
    if (it == meta_.end()) { err_code=404; err_msg="paper_not_found"; return false; }
    m = it->second;
  }
  if (!Has(m.reviewers, s.username)) { err_code=403; err_msg="not_assigned"; return false; }

  string path = PaperFile(paper_id, m.current_version);
  string content;
  if (!ReadTextFileLocked(path, content)) { err_code=500; err_msg="read_failed"; return false; }
  out_body = content;
  return true;
}

bool PaperService::ReviewsGive(const string& token, const string& paper_id, const string& review_content,
                               int& err_code, string& err_msg) {
  err_code=0; err_msg.clear();
  if (token.empty() || paper_id.empty() || review_content.empty()) {
    err_code=400; err_msg="empty_fields"; return false;
  }

  SessionInfo s;
  auto st = auth_->CheckToken(token, &s);
  if (st != TokenState::OK) {
    err_code = (st==TokenState::EXPIRED?403:(st==TokenState::NOT_FOUND?404:400));
    err_msg  = (st==TokenState::EXPIRED?"token_expired":(st==TokenState::NOT_FOUND?"token_not_found":"empty_token"));
    return false;
  }
  if (s.role != "REVIEWER") { err_code=403; err_msg="permission_denied"; return false; }

  scoped_lock lk(g_fs_mu, mu_);

  auto it = meta_.find(paper_id);
  if (it == meta_.end()) { err_code=404; err_msg="paper_not_found"; return false; }

  // Spec: ACCEPTED forbids REVIEWS_GIVE
  if (it->second.status == PaperStatus::ACCEPTED) { err_code=400; err_msg="paper_accepted_no_review"; return false; }

  if (!Has(it->second.reviewers, s.username)) { err_code=403; err_msg="not_assigned"; return false; }
  if (it->second.status != PaperStatus::UNDER_REVIEW) { err_code=400; err_msg="paper_not_under_review"; return false; }

  const string v = it->second.current_version;
  std::filesystem::create_directories(ReviewsDir(paper_id, v));
  string f = ReviewsDir(paper_id, v) + "/" + s.username + ".txt";
  if (!WriteTextFileLocked(f, review_content)) { err_code=500; err_msg="write_failed"; return false; }

  // If all done => FINISH_REVIEW
  if (AllReviewsDoneLocked(it->second)) {
    it->second.status = PaperStatus::FINISH_REVIEW;

    ofstream fout(meta_path_, ios::trunc);
    if (!fout.is_open()) { err_code=500; err_msg="meta_write_failed"; return false; }
    for (auto& kv : meta_) {
      auto& mm = kv.second;
      fout << mm.paper_id << ","
           << mm.author << ","
           << StatusToString(mm.status) << ","
           << JoinSemi(mm.reviewers) << ","
           << mm.current_version << "\n";
    }
  }
  return true;
}

bool PaperService::Tasks(const string& token,
                         string& out_body, int& err_code, string& err_msg) {
  err_code=0; err_msg.clear(); out_body.clear();
  if (token.empty()) { err_code=400; err_msg="empty_token"; return false; }

  SessionInfo s;
  auto st = auth_->CheckToken(token, &s);
  if (st != TokenState::OK) {
    err_code = (st==TokenState::EXPIRED?403:(st==TokenState::NOT_FOUND?404:400));
    err_msg  = (st==TokenState::EXPIRED?"token_expired":(st==TokenState::NOT_FOUND?"token_not_found":"empty_token"));
    return false;
  }
  if (s.role != "REVIEWER") { err_code=403; err_msg="permission_denied"; return false; }

  scoped_lock lk(g_fs_mu, mu_);

  ostringstream oss;
  for (auto& kv : meta_) {
    const auto& m = kv.second;
    if (!Has(m.reviewers, s.username)) continue;

    bool done = false;
    string f = ReviewsDir(m.paper_id, m.current_version) + "/" + s.username + ".txt";
    done = std::filesystem::exists(f);
    oss << m.paper_id << " " << (done ? "DONE" : "PENDING") << "\n";
  }
  out_body = oss.str();
  return true;
}

bool PaperService::Assign(const string& token, const string& paper_id, const string& reviewer_username,
                          int& err_code, string& err_msg) {
  err_code=0; err_msg.clear();
  if (token.empty() || paper_id.empty() || reviewer_username.empty()) {
    err_code=400; err_msg="empty_fields"; return false;
  }

  SessionInfo s;
  auto st = auth_->CheckToken(token, &s);
  if (st != TokenState::OK) {
    err_code = (st==TokenState::EXPIRED?403:(st==TokenState::NOT_FOUND?404:400));
    err_msg  = (st==TokenState::EXPIRED?"token_expired":(st==TokenState::NOT_FOUND?"token_not_found":"empty_token"));
    return false;
  }
  if (s.role != "EDITOR") { err_code=403; err_msg="permission_denied"; return false; }

  // reviewer must exist and role=REVIEWER
  UserInfo u;
  if (!auth_->UserExists(reviewer_username, &u) || u.role != "REVIEWER") {
    err_code=404; err_msg="reviewer_not_found";
    return false;
  }

  scoped_lock lk(g_fs_mu, mu_);

  auto it = meta_.find(paper_id);
  if (it == meta_.end()) { err_code=404; err_msg="paper_not_found"; return false; }

  // Spec: ACCEPTED forbids ASSIGN
  if (it->second.status == PaperStatus::ACCEPTED) { err_code=400; err_msg="paper_accepted_no_assign"; return false; }
  // (optional strictness) REJECTED should be revised first
  if (it->second.status == PaperStatus::REJECTED) { err_code=400; err_msg="paper_rejected_need_revise"; return false; }

  // If SUBMITTED or FINISH_REVIEW => set UNDER_REVIEW
  if (it->second.status == PaperStatus::SUBMITTED || it->second.status == PaperStatus::FINISH_REVIEW) {
    it->second.status = PaperStatus::UNDER_REVIEW;
  }

  AddUnique(it->second.reviewers, reviewer_username);

  // ensure dir exists
  std::filesystem::create_directories(ReviewsDir(paper_id, it->second.current_version));

  // persist meta
  ofstream fout(meta_path_, ios::trunc);
  if (!fout.is_open()) { err_code=500; err_msg="meta_write_failed"; return false; }
  for (auto& kv : meta_) {
    auto& mm = kv.second;
    fout << mm.paper_id << ","
         << mm.author << ","
         << StatusToString(mm.status) << ","
         << JoinSemi(mm.reviewers) << ","
         << mm.current_version << "\n";
  }
  return true;
}

bool PaperService::Decide(const string& token, const string& paper_id, const string& decision,
                          int& err_code, string& err_msg) {
  err_code=0; err_msg.clear();
  if (token.empty() || paper_id.empty() || decision.empty()) {
    err_code=400; err_msg="empty_fields"; return false;
  }

  SessionInfo s;
  auto st = auth_->CheckToken(token, &s);
  if (st != TokenState::OK) {
    err_code = (st==TokenState::EXPIRED?403:(st==TokenState::NOT_FOUND?404:400));
    err_msg  = (st==TokenState::EXPIRED?"token_expired":(st==TokenState::NOT_FOUND?"token_not_found":"empty_token"));
    return false;
  }
  if (s.role != "EDITOR") { err_code=403; err_msg="permission_denied"; return false; }

  string d = decision;
  if (d != "ACCEPT" && d != "REJECT") { err_code=400; err_msg="invalid_decision"; return false; }

  scoped_lock lk(g_fs_mu, mu_);

  auto it = meta_.find(paper_id);
  if (it == meta_.end()) { err_code=404; err_msg="paper_not_found"; return false; }
  if (it->second.status != PaperStatus::FINISH_REVIEW) { err_code=400; err_msg="paper_not_finish_review"; return false; }

  it->second.status = (d=="ACCEPT" ? PaperStatus::ACCEPTED : PaperStatus::REJECTED);

  // persist meta
  ofstream fout(meta_path_, ios::trunc);
  if (!fout.is_open()) { err_code=500; err_msg="meta_write_failed"; return false; }
  for (auto& kv : meta_) {
    auto& mm = kv.second;
    fout << mm.paper_id << ","
         << mm.author << ","
         << StatusToString(mm.status) << ","
         << JoinSemi(mm.reviewers) << ","
         << mm.current_version << "\n";
  }
  return true;
}

bool PaperService::Reviews(const string& token, const string& paper_id,
                           string& out_body, int& err_code, string& err_msg) {
  err_code=0; err_msg.clear(); out_body.clear();
  if (token.empty() || paper_id.empty()) { err_code=400; err_msg="empty_fields"; return false; }

  SessionInfo s;
  auto st = auth_->CheckToken(token, &s);
  if (st != TokenState::OK) {
    err_code = (st==TokenState::EXPIRED?403:(st==TokenState::NOT_FOUND?404:400));
    err_msg  = (st==TokenState::EXPIRED?"token_expired":(st==TokenState::NOT_FOUND?"token_not_found":"empty_token"));
    return false;
  }
  if (s.role != "EDITOR") { err_code=403; err_msg="permission_denied"; return false; }

  lock_guard<mutex> fs(g_fs_mu);
  PaperMeta m;
  {
    lock_guard<mutex> lk(mu_);
    auto it = meta_.find(paper_id);
    if (it == meta_.end()) { err_code=404; err_msg="paper_not_found"; return false; }
    m = it->second;
  }

  string rdir = ReviewsDir(paper_id, m.current_version);
  if (!std::filesystem::exists(rdir)) { out_body=""; return true; }

  ostringstream oss;
  for (auto& ent : std::filesystem::directory_iterator(rdir)) {
    if (!ent.is_regular_file()) continue;
    string path = ent.path().string();
    string name = ent.path().filename().string();
    string content;
    if (ReadTextFileLocked(path, content)) {
      oss << "----- " << name << " -----\n";
      oss << content;
      if (!content.empty() && content.back()!='\n') oss << "\n";
    }
  }
  out_body = oss.str();
  return true;
}

bool PaperService::Queue(const string& token,
                         string& out_body, int& err_code, string& err_msg) {
  err_code = 0;
  err_msg.clear();
  out_body.clear();

  if (token.empty()) {
    err_code = 400;
    err_msg = "empty_token";
    return false;
  }

  SessionInfo s;
  auto st = auth_->CheckToken(token, &s);
  if (st != TokenState::OK) {
    err_code = (st == TokenState::EXPIRED ? 403 :
               (st == TokenState::NOT_FOUND ? 404 : 400));
    err_msg  = (st == TokenState::EXPIRED ? "token_expired" :
               (st == TokenState::NOT_FOUND ? "token_not_found" : "empty_token"));
    return false;
  }

  if (s.role != "EDITOR") {
    err_code = 403;
    err_msg = "permission_denied";
    return false;
  }

  std::scoped_lock lk(g_fs_mu, mu_);

  std::ostringstream oss;
  for (const auto& kv : meta_) {
    const auto& m = kv.second;
    oss << m.paper_id << " " << StatusToString(m.status) << "\n";
  }

  out_body = oss.str();
  return true;
}


bool PaperService::UserHasNoUnfinishedTasks(const string& username, const string& role, string& why) {
  why.clear();

  // strict: lock all resources
  scoped_lock lk(g_fs_mu, mu_);

  if (role == "AUTHOR") {
    for (auto& kv : meta_) {
      const auto& m = kv.second;
      if (m.author != username) continue;
      if (!(m.status == PaperStatus::ACCEPTED || m.status == PaperStatus::REJECTED)) {
        why = "author_has_unfinished_paper:" + m.paper_id;
        return false;
      }
    }
    return true;
  }

  if (role == "REVIEWER") {
    for (auto& kv : meta_) {
      const auto& m = kv.second;
      if (!Has(m.reviewers, username)) continue;

      // unfinished if UNDER_REVIEW and no review file
      if (m.status == PaperStatus::UNDER_REVIEW) {
        string f = ReviewsDir(m.paper_id, m.current_version) + "/" + username + ".txt";
        if (!std::filesystem::exists(f)) {
          why = "reviewer_pending:" + m.paper_id;
          return false;
        }
      }
    }
    return true;
  }

  // EDITOR (and others): no extra restriction
  return true;
}
