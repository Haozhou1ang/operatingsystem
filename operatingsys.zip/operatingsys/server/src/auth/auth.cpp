//server/src/auth/auth.cpp
#include "auth/auth.h"
#include <fstream>
#include <sstream>
#include <random>
#include <filesystem>

using namespace std;

static bool IsValidSimpleName(const std::string& s) {
  if (s.empty()) return false;
  for (unsigned char c : s) {
    if ((c >= 'a' && c <= 'z') ||
        (c >= 'A' && c <= 'Z') ||
        (c >= '0' && c <= '9') ||
        c == '_' || c == '-') {
      continue;
    }
    return false;
  }
  return true;
}

static vector<string> SplitCSVLine(const string& line) {
  vector<string> out;
  string cur;
  bool inq = false;
  for (char c : line) {
    if (c == '"') { inq = !inq; continue; }
    if (!inq && c == ',') { out.push_back(cur); cur.clear(); }
    else cur.push_back(c);
  }
  out.push_back(cur);
  return out;
}

static string Trim(string s) {
  while (!s.empty() && (s.back()=='\r' || s.back()=='\n' || s.back()==' ' || s.back()=='\t')) s.pop_back();
  size_t i=0;
  while (i<s.size() && (s[i]==' '||s[i]=='\t')) i++;
  return s.substr(i);
}

AuthManager::AuthManager(std::string root_dir, int token_ttl_sec)
  : root_(std::move(root_dir)), ttl_sec_(token_ttl_sec) {
  users_path_ = root_ + "/users.csv";
  sessions_path_ = root_ + "/session.csv";
}

bool AuthManager::IsValidRole(const string& r) {
  return r=="ADMIN" || r=="EDITOR" || r=="REVIEWER" || r=="AUTHOR";
}

string AuthManager::GenToken() {
  static std::random_device rd;
  static std::mt19937_64 gen(rd());
  static std::uniform_int_distribution<unsigned long long> dis;

  unsigned long long a = dis(gen);
  unsigned long long b = dis(gen);
  std::ostringstream oss;
  oss << std::hex << a << b;
  return oss.str();
}

bool AuthManager::Init() {
  std::lock_guard<std::mutex> lk(mu_);
  std::filesystem::create_directories(root_);

  bool uok = LoadUsers();
  bool sok = LoadSessions();

  // If users.csv missing/empty => init default users (方便你联调)
  if (!uok || users_.empty()) {
    users_.clear();
    users_["admin"]   = {"admin","123","ADMIN"};
    users_["alice"]   = {"alice","123","AUTHOR"};
    users_["reviewer"]= {"reviewer","123","REVIEWER"};
    users_["editor"]  = {"editor","123","EDITOR"};
    users_["reviewer1"]  = {"reviewer1","123","REVIEWER"};
    users_["bob"]   = {"bob","123","AUTHOR"};
    SaveUsers();
  }
  if (!sok) {
    sessions_.clear();
    user2token_.clear();
    SaveSessions();
  }
  return true;
}

bool AuthManager::LoadUsers() {
  users_.clear();
  ifstream fin(users_path_);
  if (!fin.is_open()) return false;

  string line;
  while (std::getline(fin, line)) {
    line = Trim(line);
    if (line.empty()) continue;
    auto cols = SplitCSVLine(line);
    if (cols.size() < 3) continue;
    UserInfo u{Trim(cols[0]), Trim(cols[1]), Trim(cols[2])};
    if (u.username.empty() || u.password.empty() || !IsValidRole(u.role)) continue;
    users_[u.username] = u;
  }
  return true;
}

bool AuthManager::LoadSessions() {
  sessions_.clear();
  user2token_.clear();
  ifstream fin(sessions_path_);
  if (!fin.is_open()) return false;

  string line;
  while (std::getline(fin, line)) {
    line = Trim(line);
    if (line.empty()) continue;
    auto cols = SplitCSVLine(line);
    if (cols.size() < 4) continue;
    SessionInfo s;
    s.username = Trim(cols[0]);
    s.token    = Trim(cols[1]);
    s.create_time = (std::time_t)std::stoll(Trim(cols[2]));
    s.role     = Trim(cols[3]);
    if (s.username.empty() || s.token.empty() || !IsValidRole(s.role)) continue;
    sessions_[s.token] = s;
    user2token_[s.username] = s.token;
  }
  return true;
}

bool AuthManager::SaveUsers() {
  ofstream fout(users_path_, ios::trunc);
  if (!fout.is_open()) return false;
  for (auto& kv : users_) {
    auto& u = kv.second;
    fout << u.username << "," << u.password << "," << u.role << "\n";
  }
  return true;
}

bool AuthManager::SaveSessions() {
  ofstream fout(sessions_path_, ios::trunc);
  if (!fout.is_open()) return false;
  for (auto& kv : sessions_) {
    auto& s = kv.second;
    fout << s.username << "," << s.token << "," << (long long)s.create_time << "," << s.role << "\n";
  }
  return true;
}

TokenState AuthManager::CheckToken(const string& token, SessionInfo* out_session) {
  if (token.empty()) return TokenState::EMPTY;

  std::lock_guard<std::mutex> lk(mu_);
  auto it = sessions_.find(token);
  if (it == sessions_.end()) return TokenState::NOT_FOUND;

  std::time_t now = std::time(nullptr);
  if (ttl_sec_ > 0 && (now - it->second.create_time) > ttl_sec_) {
    // NEW: expired => delete session + user2token mapping + persist
    const std::string username = it->second.username;

    sessions_.erase(it);
    auto it2 = user2token_.find(username);
    if (it2 != user2token_.end() && it2->second == token) {
      user2token_.erase(it2);
    }

    SaveSessions();
    return TokenState::EXPIRED;
  }

  if (out_session) *out_session = it->second;
  return TokenState::OK;
}


bool AuthManager::GetSessionByToken(const string& token, SessionInfo& out) {
  std::lock_guard<std::mutex> lk(mu_);
  auto it = sessions_.find(token);
  if (it == sessions_.end()) return false;
  out = it->second;
  return true;
}

bool AuthManager::UserExists(const string& username, UserInfo* out) {
  std::lock_guard<std::mutex> lk(mu_);
  auto it = users_.find(username);
  if (it == users_.end()) return false;
  if (out) *out = it->second;
  return true;
}

bool AuthManager::Login(const string& username, const string& password,
                        string& out_role, string& out_token,
                        int& err_code, string& err_msg) {
  err_code = 0; err_msg.clear();
  if (username.empty() || password.empty()) {
    err_code = 400; err_msg = "empty_username_or_password";
    return false;
  }

  std::lock_guard<std::mutex> lk(mu_);
  auto it = users_.find(username);
  if (it == users_.end() || it->second.password != password) {
    err_code = 401; err_msg = "invalid_credentials";
    return false;
  }

  // if already has token => delete old session row
  auto it2 = user2token_.find(username);
  if (it2 != user2token_.end()) {
    sessions_.erase(it2->second);
    user2token_.erase(it2);
  }

  SessionInfo s;
  s.username = username;
  s.role = it->second.role;
  s.token = GenToken();
  s.create_time = std::time(nullptr);

  sessions_[s.token] = s;
  user2token_[username] = s.token;
  SaveSessions();

  out_role = s.role;
  out_token = s.token;
  return true;
}

bool AuthManager::Logout(const string& token, int& err_code, string& err_msg) {
  err_code = 0; err_msg.clear();
  if (token.empty()) {
    err_code = 400; err_msg = "empty_token";
    return false;
  }

  std::lock_guard<std::mutex> lk(mu_);
  auto it = sessions_.find(token);
  if (it == sessions_.end()) {
    err_code = 404; err_msg = "token_not_found";
    return false;
  }
  std::time_t now = std::time(nullptr);
  if (ttl_sec_ > 0 && (now - it->second.create_time) > ttl_sec_) {
    // expired: still can delete? spec says error and delete on success path
    err_code = 403; err_msg = "token_expired";
    return false;
  }

  user2token_.erase(it->second.username);
  sessions_.erase(it);
  SaveSessions();
  return true;
}

bool AuthManager::UserAdd(const string& token, const string& username,
                          const string& password, const string& role,
                          int& err_code, string& err_msg) {
  err_code = 0; err_msg.clear();
  if (token.empty() || username.empty() || password.empty() || role.empty()) {
    err_code = 400; err_msg = "empty_fields";
    return false;
  }

  // NEW: username allow [A-Za-z0-9_-]
  if (!IsValidSimpleName(username)) {
    err_code = 400;
    err_msg = "invalid_username";
    return false;
  }

  SessionInfo s;
  auto st = CheckToken(token, &s);
  if (st != TokenState::OK) {
    err_code = (st==TokenState::EXPIRED?403:(st==TokenState::NOT_FOUND?404:400));
    err_msg = (st==TokenState::EXPIRED?"token_expired":(st==TokenState::NOT_FOUND?"token_not_found":"empty_token"));
    return false;
  }
  if (s.role != "ADMIN") {
    err_code = 403; err_msg = "permission_denied";
    return false;
  }
  if (!IsValidRole(role)) {
    err_code = 400; err_msg = "invalid_role";
    return false;
  }

  std::lock_guard<std::mutex> lk(mu_);
  if (users_.find(username) != users_.end()) {
    err_code = 409; err_msg = "user_exists";
    return false;
  }
  users_[username] = {username, password, role};
  SaveUsers();
  return true;
}


bool AuthManager::UserDel(const string& token, const string& username,
                          int& err_code, string& err_msg,
                          const function<bool(const string&, const string&, string& why)>& unfinished_check) {
  err_code = 0; err_msg.clear();
  if (token.empty() || username.empty()) {
    err_code = 400; err_msg = "empty_fields";
    return false;
  }

  SessionInfo s;
  auto st = CheckToken(token, &s);
  if (st != TokenState::OK) {
    err_code = (st==TokenState::EXPIRED?403:(st==TokenState::NOT_FOUND?404:400));
    err_msg = (st==TokenState::EXPIRED?"token_expired":(st==TokenState::NOT_FOUND?"token_not_found":"empty_token"));
    return false;
  }
  if (s.role != "ADMIN") {
    err_code = 403; err_msg = "permission_denied";
    return false;
  }

  std::lock_guard<std::mutex> lk(mu_);
  auto it = users_.find(username);
  if (it == users_.end()) {
    err_code = 404; err_msg = "user_not_found";
    return false;
  }
  if (it->second.role == "ADMIN") {
    err_code = 400; err_msg = "cannot_delete_admin";
    return false;
  }

  // must be offline
  if (user2token_.find(username) != user2token_.end()) {
    err_code = 409; err_msg = "user_online";
    return false;
  }

  // unfinished tasks check via callback (paper service)
  if (unfinished_check) {
    string why;
    if (!unfinished_check(username, it->second.role, why)) {
      err_code = 409;
      err_msg = "user_has_unfinished_tasks";
      if (!why.empty()) err_msg += (":" + why);
      return false;
    }
  }

  // remove user and any stale session rows (defensive)
  users_.erase(it);

  for (auto sit = sessions_.begin(); sit != sessions_.end(); ) {
    if (sit->second.username == username) sit = sessions_.erase(sit);
    else ++sit;
  }
  user2token_.erase(username);

  SaveUsers();
  SaveSessions();
  return true;
}

bool AuthManager::UserList(const string& token,
                           string& out_body,
                           int& err_code, string& err_msg) {
  err_code = 0; err_msg.clear();
  out_body.clear();

  if (token.empty()) {
    err_code = 400; err_msg = "empty_token";
    return false;
  }

  SessionInfo s;
  auto st = CheckToken(token, &s);
  if (st != TokenState::OK) {
    err_code = (st==TokenState::EXPIRED?403:(st==TokenState::NOT_FOUND?404:400));
    err_msg = (st==TokenState::EXPIRED?"token_expired":(st==TokenState::NOT_FOUND?"token_not_found":"empty_token"));
    return false;
  }
  if (s.role != "ADMIN") {
    err_code = 403; err_msg = "permission_denied";
    return false;
  }

  std::lock_guard<std::mutex> lk(mu_);
  std::ostringstream oss;
  for (auto& kv : users_) {
    oss << kv.second.username << " " << kv.second.role << "\n";
  }
  out_body = oss.str();
  return true;
}
