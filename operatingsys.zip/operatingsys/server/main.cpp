// server/main.cpp
#include "auth/auth.h"
#include "services/paper.h"
#include "protocol/protocol.h"
#include "net/net.h"

#include <iostream>

int main() {
  // root dir is local folder (your requirement: virtual disk暂存本地)
  std::string root = "./paper_system";

  AuthManager auth(root, /*ttl*/3600);
  if (!auth.Init()) {
    std::cerr << "auth init failed\n";
    return 1;
  }

  PaperService paper(root, &auth);
  if (!paper.Init()) {
    std::cerr << "paper init failed\n";
    return 1;
  }

  ProtocolRouter router(&auth, &paper);

  TcpServer server("127.0.0.1", 9090, &router);
  if (!server.Start()) return 1;
  return 0;
}
