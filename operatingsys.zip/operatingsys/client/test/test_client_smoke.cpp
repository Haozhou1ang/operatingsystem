// client/test/test_client_smoke
#include <iostream>
int main() {
  std::cout << "smoke test: build OK\n";
  return 0;
}
