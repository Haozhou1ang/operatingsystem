// dummy_server.cpp
// g++ -std=c++17 dummy_server.cpp -o dummy_server
// ./dummy_server

#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>

#include <cerrno>
#include <cstring>
#include <iostream>
#include <optional>
#include <string>

// ---------- I/O helpers ----------
static bool read_exact(int fd, char* buf, size_t n) {
  size_t off = 0;
  while (off < n) {
    ssize_t r = ::read(fd, buf + off, n - off);
    if (r == 0) return false;
    if (r < 0) {
      if (errno == EINTR) continue;
      return false;
    }
    off += (size_t)r;
  }
  return true;
}

static bool write_all(int fd, const char* buf, size_t n) {
  size_t off = 0;
  while (off < n) {
    ssize_t w = ::write(fd, buf + off, n - off);
    if (w < 0) {
      if (errno == EINTR) continue;
      return false;
    }
    off += (size_t)w;
  }
  return true;
}

static std::optional<std::string> read_line(int fd, size_t max_len) {
  std::string s;
  s.reserve(64);
  char c = 0;
  while (true) {
    ssize_t r = ::read(fd, &c, 1);
    if (r == 0) return std::nullopt;
    if (r < 0) {
      if (errno == EINTR) continue;
      return std::nullopt;
    }
    s.push_back(c);
    if (c == '\n') break;
    if (s.size() > max_len) return std::nullopt;
  }
  return s;
}

// first line until '\n'
static std::string first_line(const std::string& s) {
  size_t pos = s.find('\n');
  if (pos == std::string::npos) return s;
  return s.substr(0, pos);
}

// If payload begins with "TOKEN ", drop that first line and return the rest.
// Otherwise return payload as-is.
static std::string strip_token_header(const std::string& payload) {
  if (payload.rfind("TOKEN ", 0) != 0) return payload;
  size_t pos = payload.find('\n');
  if (pos == std::string::npos) return std::string();
  return payload.substr(pos + 1);
}

static void chomp_cr(std::string& s) {
  if (!s.empty() && s.back() == '\r') s.pop_back();
}

int main() {
  int listen_fd = ::socket(AF_INET, SOCK_STREAM, 0);
  if (listen_fd < 0) {
    perror("socket");
    return 1;
  }

  int opt = 1;
  ::setsockopt(listen_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

  sockaddr_in addr{};
  addr.sin_family = AF_INET;
  addr.sin_port = htons(9090);
  addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);

  if (::bind(listen_fd, (sockaddr*)&addr, sizeof(addr)) < 0) {
    perror("bind");
    ::close(listen_fd);
    return 1;
  }

  if (::listen(listen_fd, 16) < 0) {
    perror("listen");
    ::close(listen_fd);
    return 1;
  }

  std::cout << "Dummy server listening on 127.0.0.1:9090\n";

  while (true) {
    int conn = ::accept(listen_fd, nullptr, nullptr);
    if (conn < 0) {
      perror("accept");
      continue;
    }

    bool ok = true;

    // 1) read header line "LEN <n>\n"
    auto header_opt = read_line(conn, 64);
    if (!header_opt) ok = false;

    std::string header = header_opt.value_or("");
    if (ok && header.rfind("LEN ", 0) != 0) ok = false;

    // 2) parse n
    size_t n = 0;
    if (ok) {
      try {
        n = (size_t)std::stoul(header.substr(4));
      } catch (...) {
        ok = false;
      }
    }

    // 3) read payload
    std::string payload;
    if (ok) {
      payload.assign(n, '\0');
      if (!read_exact(conn, payload.data(), n)) ok = false;
    }

    std::string response;

    if (ok) {
      std::cout << "---- received ----\n"
                << payload
                << "\n------------------\n";

      // For command matching, ignore optional TOKEN header
      std::string effective = strip_token_header(payload);
      std::string first = first_line(effective);
      chomp_cr(first);

      // LOGIN special cases: support login/LOGIN and 4 users
      if (first == "login alice 123" || first == "LOGIN alice 123") {
        response = "OK\n"
                   "token=dummy-token-123\n"
                   "role=AUTHOR\n";
      } else if (first == "login admin 123" || first == "LOGIN admin 123") {
        response = "OK\n"
                   "token=dummy-admin-123\n"
                   "role=ADMIN\n";
      } else if (first == "login editor 123" || first == "LOGIN editor 123") {
        response = "OK\n"
                   "token=dummy-editor-123\n"
                   "role=EDITOR\n";
      } else if (first == "login reviewer 123" || first == "LOGIN reviewer 123") {
        response = "OK\n"
                   "token=dummy-reviewer-123\n"
                   "role=REVIEWER\n";
      } else {
        // default: echo
        response = "OK\n" + effective;
      }
    } else {
      // best-effort error response
      response = "ERROR 500 dummy_server_bad_request\n";
    }

    // ALWAYS write back LEN + response (even if ok==false)
    std::string resp_header = "LEN " + std::to_string(response.size()) + "\n";
    (void)write_all(conn, resp_header.data(), resp_header.size());
    (void)write_all(conn, response.data(), response.size());

    ::close(conn);
  }

  ::close(listen_fd);
  return 0;
}
