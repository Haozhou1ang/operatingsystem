# File System Client – 功能测试说明（Client + Dummy Server）

本文档用于说明当前阶段客户端（Client CLI）的全部功能、测试指令、预期输出及其对应的系统功能与状态含义。  
当前阶段服务器使用 dummy_server，仅用于协议联调与客户端行为验证，不包含真实业务逻辑。

## 关于系统管理员（ADMIN）功能的说明

当前阶段系统已完成系统管理员（ADMIN）角色的**命令接口设计、权限模型与客户端支持**，  
包括用户管理、文件系统管理、备份与系统状态等命令。

由于本阶段重点在于客户端架构、协议设计与权限控制，  
服务端（server）目前使用 dummy_server 进行联调，  
未实现系统管理员相关命令的真实业务逻辑。

在当前测试中，系统管理员命令主要用于验证：
- 客户端是否正确进行角色权限校验  
- 命令参数是否合法  
- token 是否被正确注入协议  
- 客户端与服务器的通信格式是否符合设计规范  

系统管理员的真实功能（如用户管理、文件系统操作、备份与缓存管理）  
将在后续 server 模块中实现。


----------------------------------------------------------------

一、系统说明

1. 当前系统架构
- Client CLI
  - 命令解析
  - 登录态管理（token / role）
  - 角色权限控制
  - 协议格式校验
  - 自动 token 注入
- Dummy Server
  - 仅用于联调
  - LOGIN 命令返回 token 与 role
  - 其他命令返回 OK 并回显客户端发送的 payload

注意：
测试输出中出现 token（如 STATUS dummy-token-123 p1）是 dummy_server 为调试而回显请求 payload 的结果，
并不代表真实系统会在业务响应中返回 token。

----------------------------------------------------------------

二、准备工作

1. 启动 dummy_server（终端 A）

cd ~/operatingsys/tools/dummy_server
sudo fuser -k 9090/tcp || true
./dummy_server

预期输出：
Dummy server listening on 127.0.0.1:9090

2. 启动 client_cli（终端 B）

cd ~/operatingsys/client/build
./client_cli

----------------------------------------------------------------

三、未登录态测试（会话状态机）

3.1 help（未登录）

指令：
help

预期输出：
Business commands:
  ping

含义：
- SessionStore 处于未登录状态
- 仅显示不需要登录的业务命令
- help 根据当前会话状态动态生成

----------------

3.2 whoami（未登录）

指令：
whoami

预期输出：
Not logged in.

含义：
- 客户端正确识别未登录状态
- 未向服务器发送请求

----------------

3.3 未登录直接执行业务命令

指令：
papers

预期输出：
Not logged in.

含义：
- 客户端本地权限拦截生效
- 非法请求未发送给服务器

----------------------------------------------------------------

四、AUTHOR（alice）角色测试

4.1 登录 AUTHOR

指令：
login alice 123

预期输出：
OK
Logged in. role=AUTHOR

含义：
- 客户端发送 LOGIN 请求
- 成功解析 token 与 role
- SessionStore 更新为 AUTHOR

----------------

4.2 help（AUTHOR）

指令：
help

预期输出示例：
Business commands:
  papers
  ping
  reviews_get <paper_id>
  revise <paper_id>
  status <paper_id>
  upload <paper_id>

含义：
- help 按角色过滤
- 仅显示 AUTHOR 可用命令

----------------

4.3 upload（多行 body）

指令：
upload p1
hello
END

预期输出：
OK
UPLOAD dummy-token-123 p1
hello

含义：
- 客户端进入多行 body 输入模式
- END 正确结束 body
- 协议格式：UPLOAD <token> <paper_id> + body

----------------

4.4 revise

指令：
revise p1
new version
END

预期输出：
OK
REVISE dummy-token-123 p1
new version

含义：
- AUTHOR 修订论文
- 多行 body 与 token 注入正确

----------------

4.5 status

指令：
status p1

预期输出：
OK
STATUS dummy-token-123 p1

含义：
- 无 body 业务命令
- token 自动注入验证

----------------

4.6 papers

指令：
papers

预期输出：
OK
PAPERS dummy-token-123

含义：
- AUTHOR 查询自己论文列表

----------------

4.7 reviews_get

指令：
reviews_get p1

预期输出：
OK
REVIEWS_GET dummy-token-123 p1

含义：
- AUTHOR 查询评审意见

----------------

4.8 权限拦截（AUTHOR 执行 REVIEWER 命令）

指令：
download p1

预期输出：
Permission denied for role AUTHOR

含义：
- 客户端本地角色权限控制生效

----------------------------------------------------------------

五、EDITOR（editor）角色测试

5.1 登录 EDITOR

指令：
logout
login editor 123
help

预期输出：
OK
Logged in. role=EDITOR

含义：
- 会话切换需先 logout
- SessionStore 更新为 EDITOR

----------------

5.2 queue

指令：
queue

预期输出：
OK
QUEUE dummy-editor-123

含义：
- EDITOR 查询待处理队列

----------------

5.3 assign

指令：
assign p1 reviewer1

预期输出：
OK
ASSIGN dummy-editor-123 p1 reviewer1

含义：
- 参数数量校验正确
- 协议格式正确

----------------

5.4 reviews

指令：
reviews p1

预期输出：
OK
REVIEWS dummy-editor-123 p1

含义：
- EDITOR 查看评审结果

----------------

5.5 decide

指令：
decide p1 ACCEPT

预期输出：
OK
DECIDE dummy-editor-123 p1 ACCEPT

含义：
- 枚举值校验生效（ACCEPT / REJECT）

----------------------------------------------------------------

六、REVIEWER（reviewer）角色测试

6.1 登录 REVIEWER

指令：
logout
login reviewer 123
help

预期输出：
OK
Logged in. role=REVIEWER

----------------

6.2 tasks

指令：
tasks

预期输出：
OK
TASKS dummy-reviewer-123

含义：
- REVIEWER 查询被分配任务列表

----------------

6.3 download

指令：
download p1

预期输出：
OK
DOWNLOAD dummy-reviewer-123 p1

含义：
- REVIEWER 下载被分配论文

----------------

6.4 reviews_give（多行 body）

指令：
reviews_give p1
good review
END

预期输出：
OK
REVIEWS_GIVE dummy-reviewer-123 p1
good review

含义：
- REVIEWER 提交评审
- 多行 body + token 注入正确

----------------------------------------------------------------

七、ADMIN（admin）角色测试

7.1 登录 ADMIN

指令：
logout
login admin 123
help

含义：
- ADMIN 登录成功
- help 显示系统级命令

----------------

7.2 文件系统操作

指令：
ls /tmp
read /tmp/a
write /tmp/a
hello
END
mkdir /tmp/b

预期输出示例：
OK
LS dummy-admin-123 /tmp
OK
READ dummy-admin-123 /tmp/a
OK
WRITE dummy-admin-123 /tmp/a
hello
OK
MKDIR dummy-admin-123 /tmp/b

含义：
- ADMIN 文件系统命令协议验证
- body / 非 body 命令处理正确

----------------

7.3 用户管理

指令：
user_list
user_add bob 123 REVIEWER
user_del bob

预期输出：
OK
USER_LIST dummy-admin-123
OK
USER_ADD dummy-admin-123 bob 123 REVIEWER
OK
USER_DEL dummy-admin-123 bob

含义：
- 用户管理命令参数与角色校验

----------------

7.4 备份与系统

指令：
backup_create /tmp snap1
backup_list
backup_restore snap1
system_status
cache_stats
cache_clear

预期输出：
OK
BACKUP_CREATE dummy-admin-123 /tmp snap1
OK
BACKUP_LIST dummy-admin-123
OK
BACKUP_RESTORE dummy-admin-123 snap1
OK
SYSTEM_STATUS dummy-admin-123
OK
CACHE_STATS dummy-admin-123
OK
CACHE_CLEAR dummy-admin-123

含义：
- ADMIN 系统级命令协议验证

----------------------------------------------------------------

八、阶段性总结

- 已完成客户端命令解析、登录态管理、角色权限控制
- 已完成协议组包、token 自动注入、多行 body 支持
- 当前阶段测试输出用于验证客户端行为与协议一致性
- 实际业务逻辑将在后续服务器模块中实现
